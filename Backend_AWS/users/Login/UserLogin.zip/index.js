import { DynamoDBClient, PutItemCommand } from "@aws-sdk/client-dynamodb";
import bcrypt from "bcryptjs";
import jwt from "jsonwebtoken";


const dbClient = new DynamoDBClient({ region: "us-east-2" });
const JWT_SECRET = process.env.JWT_SECRET;

export const handler = async (event) => {
    try{
        const body = JSON.parse(event.body);
        const { email, password, name } = body;

        if (!email || !password) {
            return { statusCode: 400, body: JSON.stringify({ error: "Missing fields" }) };
        }

        const params = {
            TableName: "Users",
            Item: {
                email: { S: email },
            }
        }

        const result = await dbClient.send(new GetItemCommand(params));
        let user = ""
        if(!result.Item){
            return { statusCode: 404, body: JSON.stringify({ error: "User not found" }) };
        }else {
            user = result.Item
        }

        const passwordMatch = await bcrypt.compare(password, user.password.S);
        if(!passwordMatch){
            return { statusCode: 401, body: JSON.stringify({ error: "Invalid credentials" }) };
        }

        const token = jwt.sign({ 
            userId: user.UserId.S, 
            email: user.email.S }, 
            JWT_SECRET, 
            { expiresIn: '1h' }
        );

        return {
            statusCode: 200,
            body: JSON.stringify({ message: "Login successful", token }),
        };

    }catch(err){
        console.error("Login error:", err);
        return { statusCode: 500, body: JSON.stringify({ error: "Internal server error" }) };
    }
};